//
//  EpisodioCell.swift
//  PacienteMobile
//
//  Created by Mario Hernandez on 25/03/15.
//  Copyright (c) 2015 Equinox. All rights reserved.
//

import UIKit

class EpisodioCell: UITableViewCell{
    
    @IBOutlet weak var idText: UILabel?
    
    @IBOutlet weak var fechaText: UILabel?
    
    var nivelDolor : Int = 0
    
    var localizacion : String = ""
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    
    
    
    
}
