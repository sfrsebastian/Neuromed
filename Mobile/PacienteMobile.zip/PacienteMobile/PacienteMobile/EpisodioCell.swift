//
//  EpisodioCell.swift
//  PacienteMobile
//
//  Created by Mario Hernandez on 25/03/15.
//  Copyright (c) 2015 Equinox. All rights reserved.
//

import UIKit

class EpisodioCell: UITableViewCell{
    
    @IBOutlet var idText: UILabel!
    
    @IBOutlet var fechaText: UILabel!
    
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    
    
    
    
}
