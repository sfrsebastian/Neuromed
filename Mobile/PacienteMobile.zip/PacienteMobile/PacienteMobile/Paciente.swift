//
//  Paciente.swift
//  PacienteMobile
//
//  Created by Mario Hernandez on 15/03/15.
//  Copyright (c) 2015 Equinox. All rights reserved.
//

import Foundation
